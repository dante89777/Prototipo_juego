using System.Collections;
using UnityEngine;

namespace Platformer.View
{
    /// <summary>
    /// Efecto visual de círculo expansivo. Se usa para el ataque en área del
    /// jugador y para la apertura de los cofres.
    /// </summary>
    public class CircleEffect : MonoBehaviour
    {
        [SerializeField] private float duration = 0.3f;
        [SerializeField] private float startScale = 0.2f;
        [SerializeField] private float lineWidth = 0.08f;
        [SerializeField] private int segments = 24;

        LineRenderer line;
        Color effectColor;

        /// <summary>
        /// Crea el efecto en el punto indicado y lo destruye solo.
        /// </summary>
        public static CircleEffect Spawn(Vector3 position, float radius, Color color)
        {
            var go = new GameObject("EfectoCirculo");
            go.transform.position = position;
            var effect = go.AddComponent<CircleEffect>();
            effect.effectColor = color;
            effect.BuildCircle(radius);
            effect.StartCoroutine(effect.Play());
            return effect;
        }

        void BuildCircle(float radius)
        {
            line = gameObject.AddComponent<LineRenderer>();
            line.useWorldSpace = false;
            line.loop = true;
            line.positionCount = segments;
            line.startWidth = lineWidth;
            line.endWidth = lineWidth;
            line.numCapVertices = 2;

            var shader = Shader.Find("Sprites/Default");
            if (shader == null)
                shader = Shader.Find("Universal Render Pipeline/2D/Sprite-Unlit-Default");
            if (shader == null)
                shader = Shader.Find("Unlit/Color");
            if (shader != null)
                line.material = new Material(shader);

            for (int i = 0; i < segments; i++)
            {
                float angle = i * Mathf.PI * 2f / segments;
                line.SetPosition(i, new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0f) * radius);
            }
        }

        IEnumerator Play()
        {
            line.startColor = effectColor;
            line.endColor = effectColor;

            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float k = Mathf.Clamp01(elapsed / duration);
                transform.localScale = Vector3.one * Mathf.Lerp(startScale, 1f, k);
                Color faded = new Color(effectColor.r, effectColor.g, effectColor.b, 1f - k);
                line.startColor = faded;
                line.endColor = faded;
                yield return null;
            }

            Destroy(gameObject);
        }
    }
}
