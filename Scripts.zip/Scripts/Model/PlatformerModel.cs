using Platformer.Mechanics;
using UnityEngine;

namespace Platformer.Model
{
    /// <summary>
    /// Modelo principal del juego. Contiene los datos compartidos por la
    /// simulación (jugador, cámara y punto de reaparición) y el estado de
    /// progreso de la partida: elementos obtenidos, ataques desbloqueados,
    /// monedas recogidas y gancho.
    /// Es la única fuente de verdad del estado de la partida.
    /// </summary>
    [System.Serializable]
    public class PlatformerModel
    {
        /// <summary>
        /// The virtual camera in the scene.
        /// </summary>
        public Unity.Cinemachine.CinemachineCamera virtualCamera;

        /// <summary>
        /// The main component which controls the player sprite, controlled
        /// by the user.
        /// </summary>
        public PlayerController player;

        /// <summary>
        /// The spawn point in the scene.
        /// </summary>
        public Transform spawnPoint;

        /// <summary>
        /// A global jump modifier applied to all initial jump velocities.
        /// </summary>
        public float jumpModifier = 1.5f;

        /// <summary>
        /// A global jump modifier applied to slow down an active jump when
        /// the user releases the jump input.
        /// </summary>
        public float jumpDeceleration = 0.5f;

        [System.NonSerialized] private int elementsMask;
        [System.NonSerialized] private int attacksMask;
        [System.NonSerialized] private int tokenCount;
        [System.NonSerialized] private GameElement activeElement;
        [System.NonSerialized] private bool grappleUnlocked;
        [System.NonSerialized] private string message = string.Empty;
        [System.NonSerialized] private float messageExpiry;

        /// <summary>
        /// Número de monedas (tokens) recogidas por el jugador.
        /// </summary>
        public int TokenCount => tokenCount;

        /// <summary>
        /// Elemento que el jugador tiene equipado en este momento.
        /// </summary>
        public GameElement ActiveElement => activeElement;

        /// <summary>
        /// True cuando el jugador ya abrió el cofre del gancho.
        /// </summary>
        public bool GrappleUnlocked => grappleUnlocked;

        /// <summary>
        /// True si el jugador obtuvo el elemento indicado.
        /// </summary>
        public bool HasElement(GameElement element)
        {
            if (element == GameElement.Ninguno) return false;
            return (elementsMask & Bit(element)) != 0;
        }

        /// <summary>
        /// True si el jugador desbloqueó el ataque del elemento indicado.
        /// </summary>
        public bool HasAttack(GameElement element)
        {
            if (element == GameElement.Ninguno) return false;
            return (attacksMask & Bit(element)) != 0;
        }

        /// <summary>
        /// True cuando el jugador posee los dos elementos y puede alternar
        /// entre ellos con la tecla de cambio.
        /// </summary>
        public bool CanSwitchElement => HasElement(GameElement.Fuego) && HasElement(GameElement.Rayo);

        /// <summary>
        /// Mensaje informativo que muestra el HUD. Se vacía solo cuando pasa
        /// el tiempo de duración.
        /// </summary>
        public string Message => Time.time < messageExpiry ? message : string.Empty;

        /// <summary>
        /// Registra un elemento obtenido en un cofre. El elemento recién
        /// conseguido queda equipado para que su ataque se pueda usar
        /// inmediatamente.
        /// </summary>
        public void CollectElement(GameElement element)
        {
            if (element == GameElement.Ninguno) return;
            elementsMask |= Bit(element);
            activeElement = element;
        }

        /// <summary>
        /// Registra el ataque desbloqueado por un cofre.
        /// </summary>
        public void UnlockAttack(GameElement element)
        {
            if (element == GameElement.Ninguno) return;
            attacksMask |= Bit(element);
        }

        /// <summary>
        /// Registra que el jugador ya tiene el gancho disponible.
        /// </summary>
        public void UnlockGrapple()
        {
            grappleUnlocked = true;
        }

        /// <summary>
        /// Suma una moneda al contador del jugador.
        /// </summary>
        public void CollectToken()
        {
            tokenCount++;
        }

        /// <summary>
        /// Alterna entre los elementos obtenidos y devuelve el nuevo elemento
        /// activo.
        /// </summary>
        public GameElement SwitchElement()
        {
            if (!CanSwitchElement) return activeElement;
            activeElement = activeElement == GameElement.Fuego ? GameElement.Rayo : GameElement.Fuego;
            return activeElement;
        }

        /// <summary>
        /// Muestra un mensaje en el HUD durante el tiempo indicado.
        /// </summary>
        public void ShowMessage(string text, float duration = 3f)
        {
            message = text;
            messageExpiry = Time.time + duration;
        }

        /// <summary>
        /// Limpia el progreso de la partida. Se ejecuta al iniciar el juego.
        /// </summary>
        public void ResetProgress()
        {
            elementsMask = 0;
            attacksMask = 0;
            tokenCount = 0;
            activeElement = GameElement.Ninguno;
            grappleUnlocked = false;
            message = string.Empty;
            messageExpiry = 0f;
        }

        /// <summary>
        /// Copia la configuración guardada en la escena sobre este modelo
        /// manteniendo la misma instancia compartida por la simulación.
        /// </summary>
        public void CopyConfigurationFrom(PlatformerModel other)
        {
            if (other == null || ReferenceEquals(other, this)) return;
            virtualCamera = other.virtualCamera;
            player = other.player;
            spawnPoint = other.spawnPoint;
            jumpModifier = other.jumpModifier;
            jumpDeceleration = other.jumpDeceleration;
        }

        static int Bit(GameElement element)
        {
            return 1 << (int)element;
        }
    }
}
