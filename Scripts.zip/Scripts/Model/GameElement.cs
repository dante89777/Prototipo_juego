namespace Platformer.Model
{
    /// <summary>
    /// Elementos que el jugador puede obtener de los cofres del nivel.
    /// Cada elemento lleva asociado un ataque que se desbloquea al abrir
    /// el cofre correspondiente.
    /// </summary>
    public enum GameElement
    {
        /// <summary>El jugador todavía no ha obtenido ningún elemento.</summary>
        Ninguno = 0,

        /// <summary>Elemento de fuego: se obtiene en el cofre dorado.</summary>
        Fuego = 1,

        /// <summary>Elemento de rayo: se obtiene en el cofre de hierro.</summary>
        Rayo = 2
    }
}
