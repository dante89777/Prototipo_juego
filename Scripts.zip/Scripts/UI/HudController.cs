using Platformer.Core;
using Platformer.Mechanics;
using Platformer.Model;
using TMPro;
using UnityEngine;

namespace Platformer.UI
{
    /// <summary>
    /// HUD del juego. Muestra las monedas recogidas, el elemento activo, la
    /// vida del jugador y los mensajes de recompensa.
    /// </summary>
    public class HudController : MonoBehaviour
    {
        [Tooltip("Texto con el número de monedas. Se busca por nombre dentro del HUD.")]
        [SerializeField] private string tokensLabelName = "Tokens";
        [Tooltip("Texto con el elemento activo.")]
        [SerializeField] private string elementLabelName = "Elemento";
        [Tooltip("Texto con la vida del jugador.")]
        [SerializeField] private string lifeLabelName = "Vida";
        [Tooltip("Texto para los mensajes de recompensa.")]
        [SerializeField] private string messageLabelName = "Mensaje";

        TMP_Text tokensLabel;
        TMP_Text elementLabel;
        TMP_Text lifeLabel;
        TMP_Text messageLabel;

        readonly PlatformerModel model = Simulation.GetModel<PlatformerModel>();

        void Awake()
        {
            tokensLabel = FindLabel(tokensLabelName);
            elementLabel = FindLabel(elementLabelName);
            lifeLabel = FindLabel(lifeLabelName);
            messageLabel = FindLabel(messageLabelName);
        }

        void Update()
        {
            if (tokensLabel != null)
                tokensLabel.text = $"MONEDAS: {model.TokenCount}";

            if (elementLabel != null)
                elementLabel.text = $"ELEMENTO: {NameOf(model.ActiveElement)}";

            if (lifeLabel != null)
            {
                Health health = model.player != null ? model.player.Health : null;
                if (health != null)
                    lifeLabel.text = $"VIDA: {health.CurrentHP}/{health.MaxHP}";
            }

            if (messageLabel != null)
                messageLabel.text = model.Message;
        }

        TMP_Text FindLabel(string objectName)
        {
            Transform found = transform.Find(objectName);
            return found != null ? found.GetComponent<TMP_Text>() : null;
        }

        static string NameOf(GameElement value)
        {
            switch (value)
            {
                case GameElement.Fuego: return "FUEGO";
                case GameElement.Rayo: return "RAYO";
                default: return "NINGUNO";
            }
        }
    }
}
