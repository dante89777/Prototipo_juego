using Platformer.Mechanics;
using Platformer.UI;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Platformer.UI
{
    /// <summary>
    /// The MetaGameController is responsible for switching control between the high level
    /// contexts of the application, eg the Main Menu and Gameplay systems.
    /// </summary>
    public class MetaGameController : MonoBehaviour
    {
        /// <summary>
        /// The main UI object which used for the menu.
        /// </summary>
        [SerializeField] private MainUIController mainMenu;

        /// <summary>
        /// A list of canvas objects which are used during gameplay (when the main ui is turned off)
        /// </summary>
        [SerializeField] private Canvas[] gamePlayCanvasii;

        /// <summary>
        /// The game controller.
        /// </summary>
        [SerializeField] private GameController gameController;

        bool showMainCanvas = false;
        private InputAction m_MenuAction;

        /// <summary>
        /// The game controller driven by this meta controller.
        /// </summary>
        public GameController GameController => gameController;

        void OnEnable()
        {
            _ToggleMainMenu(showMainCanvas);
            m_MenuAction = InputSystem.actions.FindAction("Player/Menu");
        }

        /// <summary>
        /// Turn the main menu on or off.
        /// </summary>
        /// <param name="show"></param>
        public void ToggleMainMenu(bool show)
        {
            if (this.showMainCanvas != show)
            {
                _ToggleMainMenu(show);
            }
        }

        void _ToggleMainMenu(bool show)
        {
            if (show)
            {
                Time.timeScale = 0;
                mainMenu.gameObject.SetActive(true);
                foreach (var i in gamePlayCanvasii) i.gameObject.SetActive(false);
            }
            else
            {
                Time.timeScale = 1;
                mainMenu.gameObject.SetActive(false);
                foreach (var i in gamePlayCanvasii) i.gameObject.SetActive(true);
            }
            this.showMainCanvas = show;
        }

        void Update()
        {
            if (m_MenuAction.WasPressedThisFrame())
            {
                ToggleMainMenu(show: !showMainCanvas);
            }
        }

    }
}
